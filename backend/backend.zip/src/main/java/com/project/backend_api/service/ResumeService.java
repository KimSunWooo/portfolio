package com.project.backend_api.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.project.backend_api.domain.resume.*;
import com.project.backend_api.dto.resume.*;
import com.project.backend_api.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import java.util.List;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
@RequiredArgsConstructor
public class ResumeService {

    private final ProfileRepository profileRepository;
    private final SkillRepository skillRepository;
    private final ExperienceRepository experienceRepository;
    private final EducationRepository educationRepository;
    private final IntroductionRepository introductionRepository;

    // S3 클라이언트 주입
    private final AmazonS3 amazonS3;

    // S3 버킷 이름 주입
    @Value("${cloud.aws.s3.bucket}")
    private String bucket;

    @Transactional(readOnly = true)
    public ResumeResponse getResume() {
        return new ResumeResponse(
                getProfileOrNull(),
                skillRepository.findAllByOrderBySortOrderAscIdAsc(),
                experienceRepository.findAllByOrderBySortOrderAscIdAsc(),
                educationRepository.findAllByOrderBySortOrderAscIdAsc(),
                introductionRepository.findAllByOrderBySortOrderAscIdAsc()
        );
    }

    @Transactional(readOnly = true)
    public Profile getProfile() {
        Profile profile = getProfileOrNull();
        if (profile == null) throw new ResponseStatusException(NOT_FOUND, "프로필이 없습니다.");
        return profile;
    }

    @Transactional
    public void updateProfile(
            ProfileUpdateRequest request,
            MultipartFile profileImage
    ) {
        Profile profile = getProfile();

        // 이름, 직무, 이메일, 전화번호, Github, 소개글 수정
        profile.update(request);

        // 새 프로필 이미지가 들어온 경우에만 이미지 변경
        if (profileImage != null && !profileImage.isEmpty()) {
            String imageUrl = saveProfileImage(profileImage);
            profile.updateProfileImage(imageUrl);
        }
    }

    private String saveProfileImage(MultipartFile file) {
        try {
            // 1. 확장자 추출
            String originalFilename = file.getOriginalFilename();
            String extension = "";

            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }

            // 2. UUID 파일명 및 S3 경로 설정 ("profile/" 폴더에 저장)
            String filename = UUID.randomUUID() + extension;
            String objectName = "profile/" + filename;

            // 3. S3 메타데이터 설정
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentType(file.getContentType());
            metadata.setContentLength(file.getSize());

            // 4. S3에 파일 업로드
            amazonS3.putObject(new PutObjectRequest(
                    bucket, 
                    objectName, 
                    file.getInputStream(), 
                    metadata
            ));

            // 5. 업로드된 파일의 S3 URL 반환
            return amazonS3.getUrl(bucket, objectName).toString();

        } catch (IOException e) {
            throw new RuntimeException("프로필 이미지(S3) 저장에 실패했습니다.", e);
        }
    }

    @Transactional(readOnly = true)
    public List<Skill> getSkills() {
        return skillRepository.findAllByOrderBySortOrderAscIdAsc();
    }

    @Transactional
    public Skill createSkill(SkillRequest request) {
        return skillRepository.save(Skill.create(request));
    }

    @Transactional
    public Skill updateSkill(Integer id, SkillRequest request) {
        Skill skill = skillRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "기술을 찾을 수 없습니다. id=" + id));
        skill.update(request);
        return skill;
    }

    @Transactional
    public void deleteSkill(Integer id) {
        if (!skillRepository.existsById(id)) throw new ResponseStatusException(NOT_FOUND, "기술을 찾을 수 없습니다. id=" + id);
        skillRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Experience> getExperiences() {
        return experienceRepository.findAllByOrderBySortOrderAscIdAsc();
    }

    @Transactional
    public Experience createExperience(ExperienceRequest request) {
        return experienceRepository.save(Experience.create(request));
    }

    @Transactional
    public Experience updateExperience(Integer id, ExperienceRequest request) {
        Experience experience = experienceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "경력을 찾을 수 없습니다. id=" + id));
        experience.update(request);
        return experience;
    }

    @Transactional
    public void deleteExperience(Integer id) {
        if (!experienceRepository.existsById(id)) throw new ResponseStatusException(NOT_FOUND, "경력을 찾을 수 없습니다. id=" + id);
        experienceRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Education> getEducations() {
        return educationRepository.findAllByOrderBySortOrderAscIdAsc();
    }

    @Transactional
    public Education createEducation(EducationRequest request) {
        return educationRepository.save(Education.create(request));
    }

    @Transactional
    public Education updateEducation(Integer id, EducationRequest request) {
        Education education = educationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "학력을 찾을 수 없습니다. id=" + id));
        education.update(request);
        return education;
    }

    @Transactional
    public void deleteEducation(Integer id) {
        if (!educationRepository.existsById(id)) throw new ResponseStatusException(NOT_FOUND, "학력을 찾을 수 없습니다. id=" + id);
        educationRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Introduction> getIntroductions() {
        return introductionRepository.findAllByOrderBySortOrderAscIdAsc();
    }

    @Transactional
    public Introduction createIntroduction(IntroductionRequest request) {
        return introductionRepository.save(Introduction.create(request));
    }

    @Transactional
    public Introduction updateIntroduction(Integer id, IntroductionRequest request) {
        Introduction introduction = introductionRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "소개글을 찾을 수 없습니다. id=" + id));
        introduction.update(request);
        return introduction;
    }

    @Transactional
    public void deleteIntroduction(Integer id) {
        if (!introductionRepository.existsById(id)) throw new ResponseStatusException(NOT_FOUND, "소개글을 찾을 수 없습니다. id=" + id);
        introductionRepository.deleteById(id);
    }

    private Profile getProfileOrNull() {
        return profileRepository.findAll().stream().findFirst().orElse(null);
    }
}
