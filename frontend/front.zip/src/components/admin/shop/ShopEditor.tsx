"use client";

import type { ShopMenu } from "@/app/admin/shop/page";

interface ShopEditorProps {
  selectedMenu: ShopMenu;
}

export default function ShopEditor({
  selectedMenu,
}: ShopEditorProps) {
  return (
    <section className="min-h-full px-8 py-8">
      {selectedMenu === "dashboard" && <DashboardEditor />}
      {selectedMenu === "products" && <ProductsEditor />}
      {selectedMenu === "orders" && <OrdersEditor />}
      {selectedMenu === "users" && <UsersEditor />}
      {selectedMenu === "settings" && <SettingsEditor />}
    </section>
  );
}

function DashboardEditor() {
  return (
    <div>
      <EditorHeader
        label="01 · OVERVIEW"
        title="Dashboard"
        description="Shop의 전체 현황을 확인합니다."
      />

      <div className="mt-10 grid grid-cols-4 gap-4 max-xl:grid-cols-2 max-md:grid-cols-1">
        <SummaryCard label="PRODUCTS" value="0" />
        <SummaryCard label="ORDERS" value="0" />
        <SummaryCard label="CUSTOMERS" value="0" />
        <SummaryCard label="SALES" value="₩0" />
      </div>
    </div>
  );
}

function ProductsEditor() {
  return (
    <div>
      <EditorHeader
        label="02 · PRODUCTS"
        title="Products"
        description="Shop에 노출되는 상품을 관리합니다."
        action={
          <button
            type="button"
            className="border border-black bg-black px-5 py-3 text-[10px] tracking-[0.14em] text-white transition hover:bg-transparent hover:text-black"
          >
            ADD PRODUCT
          </button>
        }
      />

      <div className="mt-10 border-t border-black">
        <div className="grid grid-cols-[80px_1fr_140px_120px_100px] gap-4 border-b border-black/10 py-4 text-[9px] tracking-[0.14em] text-[#777]">
          <span>IMAGE</span>
          <span>PRODUCT</span>
          <span>PRICE</span>
          <span>STATUS</span>
          <span />
        </div>

        <div className="py-16 text-center text-[11px] tracking-[0.08em] text-[#999]">
          등록된 상품이 없습니다.
        </div>
      </div>
    </div>
  );
}

function OrdersEditor() {
  return (
    <div>
      <EditorHeader
        label="03 · ORDERS"
        title="Orders"
        description="고객의 주문 내역과 주문 상태를 관리합니다."
      />

      <EmptyState message="주문 내역이 없습니다." />
    </div>
  );
}

function UsersEditor() {
  return (
    <div>
      <EditorHeader
        label="04 · CUSTOMERS"
        title="Customers"
        description="Shop에 가입한 고객 정보를 관리합니다."
      />

      <EmptyState message="등록된 고객이 없습니다." />
    </div>
  );
}

function SettingsEditor() {
  return (
    <div>
      <EditorHeader
        label="05 · SETTINGS"
        title="Shop Settings"
        description="Shop의 기본 정보를 설정합니다."
      />

      <div className="mt-10 max-w-2xl border-t border-black">
        <div className="border-b border-black/10 py-6">
          <label className="mb-2 block text-[9px] tracking-[0.14em] text-[#777]">
            SHOP NAME
          </label>

          <input
            type="text"
            placeholder="Shop name"
            className="w-full border border-black/20 bg-transparent px-4 py-3 text-sm outline-none transition focus:border-black"
          />
        </div>
      </div>
    </div>
  );
}

function EditorHeader({
  label,
  title,
  description,
  action,
}: {
  label: string;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex items-end justify-between gap-8 border-b border-black pb-6">
      <div>
        <p className="mb-3 text-[9px] tracking-[0.16em] text-[#777]">
          {label}
        </p>

        <h1 className="text-[clamp(36px,5vw,64px)] font-normal tracking-[-0.05em]">
          {title}
        </h1>

        <p className="mt-3 text-xs text-[#777]">
          {description}
        </p>
      </div>

      {action}
    </div>
  );
}

function SummaryCard({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="border border-black/15 bg-white p-6">
      <p className="text-[9px] tracking-[0.14em] text-[#777]">
        {label}
      </p>

      <p className="mt-8 text-4xl tracking-[-0.05em]">
        {value}
      </p>
    </div>
  );
}

function EmptyState({
  message,
}: {
  message: string;
}) {
  return (
    <div className="mt-10 border-t border-black py-16 text-center text-[11px] tracking-[0.08em] text-[#999]">
      {message}
    </div>
  );
}